# Shoegaze Precursor Bands

This document details the key bands that influenced and laid the groundwork for the Shoegaze genre, along with their significant albums and contributions.

## The Jesus and Mary Chain

**Key Albums:**
- "Psychocandy" (1985) - Widely considered the most direct precursor to shoegaze, combining melodic pop structures with harsh noise and feedback
- "Darklands" (1987)
- "Automatic" (1989)

**Contribution to Shoegaze:**
The Jesus and Mary Chain pioneered the combination of sweet pop melodies with abrasive noise, creating a template that many shoegaze bands would follow. Their use of feedback and distortion as musical elements rather than just effects was revolutionary. "Psychocandy" demonstrated how beautiful melodies could coexist with and be enhanced by walls of noise and distortion.

**Influences:**
- The Velvet Underground
- The Stooges
- Phil Spector's Wall of Sound
- 1960s girl groups

## Cocteau Twins

**Key Albums:**
- "Head Over Heels" (1983)
- "Treasure" (1984)
- "Heaven or Las Vegas" (1990)

**Contribution to Shoegaze:**
Cocteau Twins created ethereal, dream-like soundscapes with Elizabeth Fraser's otherworldly vocals and Robin Guthrie's heavily processed, reverb-laden guitars. Their atmospheric approach to guitar textures and the way they used vocals as another instrument rather than just a vehicle for lyrics directly influenced shoegaze's sonic palette.

**Influences:**
- Siouxsie and the Banshees
- Kate Bush
- Brian Eno
- Post-punk

## Sonic Youth

**Key Albums:**
- "Daydream Nation" (1988)
- "Sister" (1987)
- "EVOL" (1986)

**Contribution to Shoegaze:**
Sonic Youth's experimental approach to guitar tunings and their creation of vast, noisy soundscapes provided a blueprint for shoegaze guitarists. Their use of feedback as a compositional element and their ability to create beauty from dissonance were particularly influential.

**Influences:**
- Glenn Branca
- No Wave scene
- The Velvet Underground
- Krautrock

## Dinosaur Jr.

**Key Albums:**
- "You're Living All Over Me" (1987)
- "Bug" (1988)
- "Green Mind" (1991)

**Contribution to Shoegaze:**
Dinosaur Jr. combined melodic sensitivity with raw, distorted guitar work. J Mascis's guitar solos and the band's approach to dynamics—alternating between quiet passages and explosive noise—influenced shoegaze bands' approach to composition and guitar playing.

**Influences:**
- Neil Young
- Hardcore punk
- Black Sabbath
- The Cure

## The Velvet Underground

**Key Albums:**
- "The Velvet Underground & Nico" (1967)
- "White Light/White Heat" (1968)
- "The Velvet Underground" (1969)

**Contribution to Shoegaze:**
The Velvet Underground pioneered the use of drone, feedback, and noise in rock music. Their experimental approach to sound and their combination of avant-garde elements with pop structures laid groundwork that shoegaze would build upon decades later.

**Influences:**
- La Monte Young
- Free jazz
- Avant-garde classical music
- Garage rock

## The Cure

**Key Albums:**
- "Pornography" (1982)
- "Disintegration" (1989)
- "Faith" (1981)

**Contribution to Shoegaze:**
The Cure's atmospheric, melancholic sound and Robert Smith's introspective lyrics influenced shoegaze's emotional tone. Their use of layered guitars, reverb, and chorus effects to create immersive soundscapes was particularly influential on the genre's sonic approach.

**Influences:**
- Joy Division
- Siouxsie and the Banshees
- David Bowie
- Post-punk

## Spacemen 3

**Key Albums:**
- "The Perfect Prescription" (1987)
- "Playing with Fire" (1989)
- "Recurring" (1991)

**Contribution to Shoegaze:**
Spacemen 3's drone-heavy, psychedelic sound and their mantra of "taking drugs to make music to take drugs to" embodied the trance-like, immersive quality that shoegaze would adopt. Their minimalist approach to composition and maximalist approach to sound influenced bands like Slowdive and Ride.

**Influences:**
- The Velvet Underground
- 13th Floor Elevators
- Suicide
- Stooges

## Loop

**Key Albums:**
- "Heaven's End" (1987)
- "Fade Out" (1989)
- "A Gilded Eternity" (1990)

**Contribution to Shoegaze:**
Loop's hypnotic, repetitive rhythms and heavily processed guitars created a psychedelic, immersive sound that influenced shoegaze's approach to rhythm and texture. Their ability to create trance-like states through repetition and layered sound was particularly influential.

**Influences:**
- Krautrock
- The Stooges
- MC5
- Suicide

## The House of Love

**Key Albums:**
- "The House of Love" (1988)
- "The House of Love" (Fontana) (1990)
- "Babe Rainbow" (1992)

**Contribution to Shoegaze:**
The House of Love bridged the gap between jangle pop and the more textural approach of shoegaze. Their melodic sensibility combined with atmospheric guitar work influenced the more pop-oriented side of shoegaze.

**Influences:**
- The Velvet Underground
- Television
- Echo & the Bunnymen
- The Smiths

## A.R. Kane

**Key Albums:**
- "69" (1988)
- "i" (1989)
- "New Clear Child" (1994)

**Contribution to Shoegaze:**
A.R. Kane's experimental approach to guitar sounds and their fusion of dream pop, dub, free jazz, and psychedelia created a template for shoegaze's sonic experimentation. They've been credited with coining the term "dream pop," which is closely associated with shoegaze.

**Influences:**
- Miles Davis
- Cocteau Twins
- Dub reggae
- Free jazz

## The Beach Boys

**Key Albums:**
- "Sunflower" (1970) - Particularly the track "All I Wanna Do"
- "Pet Sounds" (1966)
- "Surf's Up" (1971)

**Contribution to Shoegaze:**
While not typically associated with shoegaze, The Beach Boys' "All I Wanna Do" from "Sunflower" has been retrospectively recognized as a precursor to the genre due to its dreamy atmosphere, reverb-drenched vocals, and immersive production. Brian Wilson's innovative production techniques and approach to creating sonic textures influenced shoegaze's emphasis on sound as much as song.

**Influences:**
- Phil Spector
- Four Freshmen
- Chuck Berry
- Classical composers
