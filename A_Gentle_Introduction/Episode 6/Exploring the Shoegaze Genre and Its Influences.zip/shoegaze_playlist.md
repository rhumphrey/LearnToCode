# Chronological Shoegaze Journey Playlist

This playlist presents one track from each album in our chronological journey through the development of shoegaze, from its precursors to its modern evolution. Each track has been selected to represent the essential sound of its album and to create a cohesive listening experience that traces the genre's development.

## Precursors and Influences (1967-1988)

1. **The Velvet Underground** - "Venus in Furs" (from "The Velvet Underground & Nico", 1967)
   * The droning viola, experimental textures, and Lou Reed's detached vocals established a template for the atmospheric experimentation that would define shoegaze decades later.

2. **The Beach Boys** - "All I Wanna Do" (from "Sunflower", 1970)
   * This dreamy track with its reverb-drenched vocals and immersive production is retrospectively viewed as proto-shoegaze, showing how atmosphere could be as important as melody.

3. **The Cure** - "The Hanging Garden" (from "Pornography", 1982)
   * The dense, atmospheric production and Robert Smith's buried vocals demonstrate the emotional intensity and textural approach that would influence shoegaze.

4. **Cocteau Twins** - "Lorelei" (from "Treasure", 1984)
   * Elizabeth Fraser's ethereal vocals and Robin Guthrie's shimmering, effects-laden guitars created a dreamlike soundscape that directly influenced shoegaze's sonic palette.

5. **The Jesus and Mary Chain** - "Just Like Honey" (from "Psychocandy", 1985)
   * The combination of sweet pop melody with walls of noise and feedback provided a direct blueprint for shoegaze's balance of beauty and abrasion.

6. **Dinosaur Jr.** - "Little Fury Things" (from "You're Living All Over Me", 1987)
   * J Mascis's melodic guitar work buried beneath layers of distortion showed how emotional vulnerability could coexist with noise and volume.

7. **Sonic Youth** - "Teenage Riot" (from "Daydream Nation", 1988)
   * The alternative tunings, textural guitar work, and buried vocals demonstrated how experimental techniques could be incorporated into accessible structures.

8. **Spacemen 3** - "Revolution" (from "Playing with Fire", 1989)
   * The hypnotic repetition, minimalist structure, and maximalist sound created a trance-like state that influenced shoegaze's immersive quality.

9. **Loop** - "Vapour" (from "A Gilded Eternity", 1990)
   * The hypnotic rhythms and heavily processed guitars created a psychedelic, immersive sound that directly preceded and influenced shoegaze.

10. **A.R. Kane** - "Baby Milk Snatcher" (from "69", 1988)
    * The experimental guitar sounds and fusion of dream pop, dub, and psychedelia created a template for shoegaze's sonic experimentation.

## Classic Shoegaze Era (1990-1995)

11. **Ride** - "Vapour Trail" (from "Nowhere", 1990)
    * The shimmering guitars, vocal harmonies, and emotional depth exemplify the more accessible side of early shoegaze.

12. **My Bloody Valentine** - "Only Shallow" (from "Loveless", 1991)
    * The definitive shoegaze track, with its thunderous drums and waves of distorted, bending guitars creating a sound unlike anything heard before.

13. **Swervedriver** - "Sci-Flyer" (from "Raise", 1991)
    * Combines shoegaze textures with driving rhythms, showing how the genre could incorporate more rock-oriented elements.

14. **Lush** - "Nothing Natural" (from "Spooky", 1992)
    * Demonstrates their melodic sensibility within the shoegaze framework, with Emma Anderson and Miki Berenyi's intertwining vocals.

15. **Catherine Wheel** - "Black Metallic" (from "Ferment", 1992)
    * An epic shoegaze ballad with soaring guitars that shows how the genre could create emotional crescendos.

16. **Slowdive** - "Alison" (from "Souvlaki", 1993)
    * Perfectly captures the band's ethereal sound with shimmering guitars and Neil Halstead's dreamy vocals.

17. **Seefeel** - "Climactic Phase No. 3" (from "Quique", 1993)
    * Demonstrates their fusion of shoegaze and electronic music, pointing toward future developments in post-rock and ambient electronic.

18. **Slowdive** - "Blue Skied an' Clear" (from "Pygmalion", 1995)
    * Combines minimalism with emotional resonance, showing shoegaze's evolution toward ambient and electronic influences.

## Revival and Evolution (2000s-Present)

19. **M83** - "Run Into Flowers" (from "Dead Cities, Red Seas & Lost Ghosts", 2003)
    * Combines electronic beats with shoegaze textures, showing how the genre influenced electronic music in the 2000s.

20. **Alcest** - "Souvenirs d'un autre monde" (from "Souvenirs d'un autre monde", 2007)
    * Combines metal intensity with shoegaze beauty, pioneering the "blackgaze" subgenre.

21. **Beach House** - "Sparks" (from "Depression Cherry", 2015)
    * Shows shoegaze's continued influence on contemporary indie music, with distorted guitars and dreamy vocals creating an immersive atmosphere.

## Listening Experience

This playlist creates a chronological journey through the development of shoegaze, from its earliest influences to its modern evolution. As you listen, you'll hear how the genre's key elements—textured guitars, buried vocals, immersive soundscapes, and the balance between noise and melody—evolved over time.

The journey begins with the experimental rock of The Velvet Underground and the dreamy pop of The Beach Boys, moves through the post-punk and gothic textures of The Cure and Cocteau Twins, and then to the noise-pop revolution of The Jesus and Mary Chain. The alternative rock experiments of Dinosaur Jr. and Sonic Youth lead into the psychedelic drones of Spacemen 3 and Loop, and the genre-blending approach of A.R. Kane.

The classic shoegaze era is represented by the definitive works of Ride, My Bloody Valentine, Swervedriver, Lush, Catherine Wheel, Slowdive, and Seefeel, showcasing the genre's diversity and emotional range. The journey concludes with examples of shoegaze's revival and evolution in the 21st century through M83, Alcest, and Beach House, demonstrating the genre's continued relevance and influence.

Together, these tracks create not just a history lesson but a cohesive listening experience that captures the essence of shoegaze: a genre that uses texture, atmosphere, and emotion to create immersive sonic worlds.
