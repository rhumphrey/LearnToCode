# Chronological Album Journey Through Shoegaze Precursors and Influences

This document presents ten albums that create an interesting chronological journey through the precursors and influences of the Shoegaze genre, tracing its musical development from the 1960s to the emergence of shoegaze in the late 1980s.

## 1. The Velvet Underground - "The Velvet Underground & Nico" (1967)

**Why It's Important**: The Velvet Underground pioneered the use of drone, feedback, and noise in rock music, elements that would become central to shoegaze. Their combination of experimental sounds with pop structures created a template that many shoegaze bands would follow decades later.

**Key Tracks**:
- "Venus in Furs" - Droning viola and experimental textures
- "Heroin" - Dynamic shifts and noise experimentation
- "Sunday Morning" - Delicate melodies beneath experimental production

**Influence on Shoegaze**: The Velvet Underground's approach to using noise as a musical element rather than just an effect directly influenced shoegaze bands like My Bloody Valentine and The Jesus and Mary Chain. Their willingness to experiment with sound while maintaining melodic structures was a blueprint for shoegaze's balance of noise and beauty.

## 2. The Beach Boys - "Sunflower" (1970)

**Why It's Important**: While not typically associated with shoegaze, "Sunflower" contains "All I Wanna Do," a track that has been retrospectively recognized as a precursor to shoegaze due to its dreamy atmosphere, reverb-drenched vocals, and immersive production.

**Key Tracks**:
- "All I Wanna Do" - Proto-shoegaze dreaminess and reverb
- "Cool, Cool Water" - Experimental production and layered vocals
- "This Whole World" - Lush harmonies and production

**Influence on Shoegaze**: Brian Wilson's innovative production techniques and approach to creating sonic textures influenced shoegaze's emphasis on sound as much as song. "All I Wanna Do" specifically demonstrates how reverb and atmosphere can create an immersive listening experience, a central tenet of shoegaze.

## 3. The Cure - "Pornography" (1982)

**Why It's Important**: "Pornography" represents The Cure at their most atmospheric and textural, with layers of guitars, reverb, and introspective lyrics creating a dense, immersive soundscape that would influence shoegaze's emotional and sonic palette.

**Key Tracks**:
- "The Hanging Garden" - Driving rhythms with atmospheric guitars
- "Siamese Twins" - Layered textures and introspective lyrics
- "Cold" - Dense, immersive soundscapes

**Influence on Shoegaze**: The Cure's approach to creating atmospheric, melancholic soundscapes with layered guitars and effects directly influenced shoegaze's emotional tone and sonic approach. Robert Smith's introspective lyrics and the band's use of effects to create mood rather than just enhance sound were particularly influential.

## 4. Cocteau Twins - "Treasure" (1984)

**Why It's Important**: "Treasure" refined Cocteau Twins' ethereal sound with more complex arrangements, featuring Elizabeth Fraser's otherworldly vocals and Robin Guthrie's heavily processed, reverb-laden guitars creating dreamlike soundscapes.

**Key Tracks**:
- "Lorelei" - Ethereal vocals and shimmering guitars
- "Persephone" - Atmospheric textures and unintelligible lyrics
- "Otterley" - Dreamy soundscapes and emotive vocals

**Influence on Shoegaze**: Cocteau Twins' atmospheric approach to guitar textures and the way they used vocals as another instrument rather than just a vehicle for lyrics directly influenced shoegaze's sonic palette. Their creation of immersive, dreamlike soundscapes became a blueprint for shoegaze's approach to creating mood and atmosphere.

## 5. The Jesus and Mary Chain - "Psychocandy" (1985)

**Why It's Important**: "Psychocandy" is widely considered the most direct precursor to shoegaze, combining sweet pop melodies with abrasive noise and feedback in a way that would directly influence the genre's development.

**Key Tracks**:
- "Just Like Honey" - Pop melody beneath layers of noise
- "You Trip Me Up" - Feedback-drenched guitars with catchy hooks
- "Never Understand" - Wall of noise with buried vocals

**Influence on Shoegaze**: The Jesus and Mary Chain pioneered the combination of sweet pop melodies with abrasive noise, creating a template that many shoegaze bands would follow. Their use of feedback and distortion as musical elements rather than just effects was revolutionary and directly influenced bands like My Bloody Valentine.

## 6. Dinosaur Jr. - "You're Living All Over Me" (1987)

**Why It's Important**: "You're Living All Over Me" combined melodic sensitivity with raw, distorted guitar work, showing how emotional vulnerability could coexist with noise and volume, a key aspect of shoegaze.

**Key Tracks**:
- "Little Fury Things" - Melodic guitar work with distortion
- "In a Jar" - Emotional vulnerability beneath noise
- "Sludgefeast" - Heavy riffs with melodic sensibility

**Influence on Shoegaze**: Dinosaur Jr.'s combination of melodic sensitivity with raw, distorted guitar work influenced shoegaze bands' approach to composition and guitar playing. J Mascis's guitar solos and the band's approach to dynamics—alternating between quiet passages and explosive noise—provided a blueprint for shoegaze's dynamic range.

## 7. Sonic Youth - "Daydream Nation" (1988)

**Why It's Important**: "Daydream Nation" represents the culmination of Sonic Youth's experimental approach to guitar tunings and their creation of vast, noisy soundscapes, elements that would be central to shoegaze.

**Key Tracks**:
- "Teenage Riot" - Alternative tunings with melodic structures
- "Silver Rocket" - Noise experimentation within song structures
- "Eric's Trip" - Textural guitar work and atmospheric production

**Influence on Shoegaze**: Sonic Youth's experimental approach to guitar tunings and their creation of vast, noisy soundscapes provided a blueprint for shoegaze guitarists. Their use of feedback as a compositional element and their ability to create beauty from dissonance were particularly influential on bands like My Bloody Valentine.

## 8. Spacemen 3 - "Playing with Fire" (1989)

**Why It's Important**: "Playing with Fire" epitomizes Spacemen 3's drone-heavy, psychedelic sound and their mantra of "taking drugs to make music to take drugs to," embodying the trance-like, immersive quality that shoegaze would adopt.

**Key Tracks**:
- "Revolution" - Hypnotic repetition and minimalism
- "Suicide" - Drone and feedback experimentation
- "How Does It Feel?" - Psychedelic textures and repetitive structures

**Influence on Shoegaze**: Spacemen 3's minimalist approach to composition and maximalist approach to sound influenced bands like Slowdive and Ride. Their ability to create trance-like states through repetition and layered sound was particularly influential on shoegaze's immersive quality.

## 9. Loop - "A Gilded Eternity" (1990)

**Why It's Important**: "A Gilded Eternity" represents the culmination of Loop's hypnotic, repetitive rhythms and heavily processed guitars, creating a psychedelic, immersive sound that directly preceded and influenced shoegaze.

**Key Tracks**:
- "Vapour" - Hypnotic rhythms and processed guitars
- "Be Here Now" - Psychedelic textures and repetitive structures
- "Blood" - Dense, immersive soundscapes

**Influence on Shoegaze**: Loop's hypnotic, repetitive rhythms and heavily processed guitars created a psychedelic, immersive sound that influenced shoegaze's approach to rhythm and texture. Their ability to create trance-like states through repetition and layered sound was particularly influential on bands like Ride and Slowdive.

## 10. A.R. Kane - "69" (1988)

**Why It's Important**: "69" showcases A.R. Kane's experimental approach to guitar sounds and their fusion of dream pop, dub, free jazz, and psychedelia, creating a template for shoegaze's sonic experimentation.

**Key Tracks**:
- "Baby Milk Snatcher" - Experimental guitar sounds and genre fusion
- "Spermwhale Trip Over" - Dreamy textures with dub influences
- "Sulliday" - Atmospheric production and ethereal vocals

**Influence on Shoegaze**: A.R. Kane's experimental approach to guitar sounds and their fusion of dream pop, dub, free jazz, and psychedelia created a template for shoegaze's sonic experimentation. They've been credited with coining the term "dream pop," which is closely associated with shoegaze, and their approach to creating immersive soundscapes directly influenced the genre's development.
