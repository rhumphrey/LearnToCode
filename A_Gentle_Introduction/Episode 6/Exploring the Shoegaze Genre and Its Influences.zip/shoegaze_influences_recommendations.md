# Influences and Album Recommendations for Shoegaze Precursor Bands

This document explores the musical influences of key shoegaze precursor bands and provides album recommendations for each, helping to trace the musical lineage that led to the shoegaze genre.

## The Jesus and Mary Chain

### Influences:
1. **The Velvet Underground** - Their use of feedback, distortion, and drone was a major influence
2. **The Stooges** - Raw energy and primitive approach to rock
3. **Phil Spector** - Wall of Sound production technique
4. **The Shangri-Las and 1960s Girl Groups** - Melodic sensibilities beneath the noise
5. **Einstürzende Neubauten** - Industrial noise elements

### Album Recommendations:
1. **The Velvet Underground** - "The Velvet Underground & Nico" (1967)
   * Essential for understanding JAMC's approach to noise and melody
   * Key tracks: "Heroin," "Venus in Furs"

2. **The Stooges** - "Fun House" (1970)
   * Raw proto-punk that influenced JAMC's aggressive sound
   * Key tracks: "T.V. Eye," "1970"

3. **The Ronettes** - "Presenting the Fabulous Ronettes" (1964)
   * Phil Spector-produced girl group that influenced JAMC's melodic approach
   * Key tracks: "Be My Baby," "Walking in the Rain"

4. **Suicide** - "Suicide" (1977)
   * Minimalist electronic duo that influenced JAMC's approach to repetition
   * Key tracks: "Ghost Rider," "Cheree"

5. **Einstürzende Neubauten** - "Kollaps" (1981)
   * Industrial noise that influenced JAMC's feedback experiments
   * Key tracks: "Kollaps," "Steh auf Berlin"

## Cocteau Twins

### Influences:
1. **Siouxsie and the Banshees** - Atmospheric post-punk and ethereal vocals
2. **Kate Bush** - Innovative vocal techniques and atmospheric production
3. **Brian Eno** - Ambient soundscapes and production techniques
4. **The Cure** - Melancholic post-punk with textured guitars
5. **Bauhaus** - Gothic atmosphere and dramatic vocals

### Album Recommendations:
1. **Siouxsie and the Banshees** - "Juju" (1981)
   * Gothic post-punk that influenced Cocteau Twins' early sound
   * Key tracks: "Spellbound," "Arabian Knights"

2. **Kate Bush** - "Hounds of Love" (1985)
   * Innovative vocal techniques and atmospheric production
   * Key tracks: "Running Up That Hill," "Cloudbusting"

3. **Brian Eno** - "Another Green World" (1975)
   * Ambient textures that influenced Cocteau Twins' soundscapes
   * Key tracks: "The Big Ship," "St. Elmo's Fire"

4. **The Cure** - "Faith" (1981)
   * Atmospheric post-punk that influenced Cocteau Twins' melancholic sound
   * Key tracks: "All Cats Are Grey," "Faith"

5. **Bauhaus** - "In the Flat Field" (1980)
   * Gothic post-punk that influenced Cocteau Twins' early dark sound
   * Key tracks: "Dark Entries," "In the Flat Field"

## Sonic Youth

### Influences:
1. **Glenn Branca** - Experimental guitar compositions and alternative tunings
2. **No Wave Scene** - Atonal, dissonant approach to rock music
3. **The Velvet Underground** - Experimental rock and noise
4. **Krautrock** (particularly Neu! and Can) - Repetitive rhythms and experimental structures
5. **Free Jazz** - Improvisational approach and dissonance

### Album Recommendations:
1. **Glenn Branca** - "The Ascension" (1981)
   * Experimental guitar compositions that directly influenced Sonic Youth's tunings
   * Key tracks: "The Ascension," "Structure"

2. **DNA** - "A Taste of DNA" (1981)
   * No Wave band that influenced Sonic Youth's dissonant approach
   * Key tracks: "Blonde Red Head," "5:30"

3. **The Velvet Underground** - "White Light/White Heat" (1968)
   * Noise rock that influenced Sonic Youth's experimental approach
   * Key tracks: "Sister Ray," "I Heard Her Call My Name"

4. **Neu!** - "Neu!" (1972)
   * Krautrock that influenced Sonic Youth's repetitive structures
   * Key tracks: "Hallogallo," "Negativland"

5. **Albert Ayler** - "Spiritual Unity" (1965)
   * Free jazz that influenced Sonic Youth's improvisational approach
   * Key tracks: "Ghosts: First Variation," "The Wizard"

## Dinosaur Jr.

### Influences:
1. **Neil Young** - Guitar solos and emotional rawness
2. **Hardcore Punk** (particularly Black Flag) - Energy and intensity
3. **Black Sabbath** - Heavy riffs and guitar tone
4. **The Cure** - Melancholic sensibility
5. **The Replacements** - Combination of punk energy and melodic songwriting

### Album Recommendations:
1. **Neil Young** - "Everybody Knows This Is Nowhere" (1969)
   * Guitar work that influenced J Mascis's playing style
   * Key tracks: "Down by the River," "Cinnamon Girl"

2. **Black Flag** - "Damaged" (1981)
   * Hardcore punk that influenced Dinosaur Jr.'s intensity
   * Key tracks: "Rise Above," "TV Party"

3. **Black Sabbath** - "Master of Reality" (1971)
   * Heavy riffs that influenced Dinosaur Jr.'s guitar tone
   * Key tracks: "Sweet Leaf," "Children of the Grave"

4. **The Cure** - "Seventeen Seconds" (1980)
   * Atmospheric post-punk that influenced Dinosaur Jr.'s melancholic side
   * Key tracks: "A Forest," "Play for Today"

5. **The Replacements** - "Let It Be" (1984)
   * Punk-influenced rock with melodic sensibility
   * Key tracks: "Unsatisfied," "Answering Machine"

## The Velvet Underground

### Influences:
1. **La Monte Young** - Drone music and minimalism
2. **Free Jazz** - Improvisational techniques and dissonance
3. **Avant-garde Classical Music** - Experimental structures
4. **Garage Rock** - Raw energy and simplicity
5. **Beat Poetry** - Lyrical approach and subject matter

### Album Recommendations:
1. **La Monte Young** - "The Well-Tuned Piano" (1964)
   * Minimalist drone music that influenced VU's approach to sustained tones
   * Key tracks: This is a single, extended composition

2. **John Coltrane** - "Ascension" (1966)
   * Free jazz that influenced VU's improvisational approach
   * Key tracks: "Ascension, Edition I"

3. **The Fugs** - "The Fugs First Album" (1965)
   * Avant-garde rock that influenced VU's experimental approach
   * Key tracks: "Slum Goddess," "I Couldn't Get High"

4. **The Sonics** - "Here Are The Sonics" (1965)
   * Garage rock that influenced VU's raw energy
   * Key tracks: "The Witch," "Psycho"

5. **Terry Riley** - "In C" (1964)
   * Minimalist composition that influenced VU's repetitive structures
   * Key tracks: "In C"

## The Cure

### Influences:
1. **Joy Division** - Post-punk darkness and atmosphere
2. **Siouxsie and the Banshees** - Gothic sensibility and guitar textures
3. **David Bowie** - Artistic reinvention and theatrical elements
4. **Jimi Hendrix** - Guitar experimentation
5. **Psychedelic Rock** - Atmospheric and textural elements

### Album Recommendations:
1. **Joy Division** - "Closer" (1980)
   * Post-punk that influenced The Cure's dark atmosphere
   * Key tracks: "Heart and Soul," "Twenty Four Hours"

2. **Siouxsie and the Banshees** - "The Scream" (1978)
   * Post-punk that influenced The Cure's guitar textures
   * Key tracks: "Jigsaw Feeling," "Metal Postcard"

3. **David Bowie** - "Low" (1977)
   * Art rock that influenced The Cure's experimental side
   * Key tracks: "Sound and Vision," "Warszawa"

4. **Jimi Hendrix** - "Electric Ladyland" (1968)
   * Guitar experimentation that influenced Robert Smith's playing
   * Key tracks: "1983... (A Merman I Should Turn to Be)," "Voodoo Child (Slight Return)"

5. **Pink Floyd** - "The Piper at the Gates of Dawn" (1967)
   * Psychedelic rock that influenced The Cure's atmospheric elements
   * Key tracks: "Astronomy Domine," "Interstellar Overdrive"

## Spacemen 3

### Influences:
1. **The Velvet Underground** - Drone and repetition
2. **13th Floor Elevators** - Psychedelic rock
3. **Suicide** - Minimalist electronic music
4. **The Stooges** - Raw energy and simplicity
5. **MC5** - Revolutionary rock attitude

### Album Recommendations:
1. **The Velvet Underground** - "White Light/White Heat" (1968)
   * Experimental rock that influenced Spacemen 3's use of drone
   * Key tracks: "Sister Ray," "I Heard Her Call My Name"

2. **13th Floor Elevators** - "The Psychedelic Sounds of the 13th Floor Elevators" (1966)
   * Psychedelic rock that influenced Spacemen 3's drug-influenced sound
   * Key tracks: "You're Gonna Miss Me," "Roller Coaster"

3. **Suicide** - "Suicide" (1977)
   * Minimalist electronic music that influenced Spacemen 3's repetitive structures
   * Key tracks: "Ghost Rider," "Cheree"

4. **The Stooges** - "The Stooges" (1969)
   * Raw proto-punk that influenced Spacemen 3's primitive approach
   * Key tracks: "I Wanna Be Your Dog," "No Fun"

5. **MC5** - "Kick Out the Jams" (1969)
   * Revolutionary rock that influenced Spacemen 3's attitude
   * Key tracks: "Kick Out the Jams," "Come Together"

## Loop

### Influences:
1. **Krautrock** (particularly Neu! and Can) - Repetitive rhythms and motorik beats
2. **The Stooges** - Raw energy and primitive approach
3. **MC5** - Revolutionary rock attitude
4. **Suicide** - Minimalist electronic music
5. **Hawkwind** - Space rock and psychedelia

### Album Recommendations:
1. **Can** - "Tago Mago" (1971)
   * Krautrock that influenced Loop's repetitive structures
   * Key tracks: "Halleluwah," "Mushroom"

2. **The Stooges** - "Fun House" (1970)
   * Raw proto-punk that influenced Loop's primitive approach
   * Key tracks: "T.V. Eye," "1970"

3. **MC5** - "Back in the USA" (1970)
   * Revolutionary rock that influenced Loop's attitude
   * Key tracks: "Looking at You," "High School"

4. **Suicide** - "Suicide: Alan Vega and Martin Rev" (1980)
   * Minimalist electronic music that influenced Loop's repetitive structures
   * Key tracks: "Dream Baby Dream," "Diamonds, Fur Coat, Champagne"

5. **Hawkwind** - "Space Ritual" (1973)
   * Space rock that influenced Loop's psychedelic elements
   * Key tracks: "Brainstorm," "Seven by Seven"

## The House of Love

### Influences:
1. **The Velvet Underground** - Melodic yet experimental approach
2. **Television** - Guitar interplay and songcraft
3. **Echo & the Bunnymen** - Atmospheric post-punk
4. **The Smiths** - Jangle pop and lyrical depth
5. **Joy Division** - Post-punk intensity

### Album Recommendations:
1. **The Velvet Underground** - "The Velvet Underground" (1969)
   * Melodic experimental rock that influenced The House of Love's approach
   * Key tracks: "Pale Blue Eyes," "What Goes On"

2. **Television** - "Marquee Moon" (1977)
   * Guitar-focused post-punk that influenced The House of Love's guitar interplay
   * Key tracks: "Marquee Moon," "Venus"

3. **Echo & the Bunnymen** - "Heaven Up Here" (1981)
   * Atmospheric post-punk that influenced The House of Love's sound
   * Key tracks: "Over the Wall," "A Promise"

4. **The Smiths** - "The Queen Is Dead" (1986)
   * Jangle pop that influenced The House of Love's melodic sensibility
   * Key tracks: "There Is a Light That Never Goes Out," "I Know It's Over"

5. **Joy Division** - "Unknown Pleasures" (1979)
   * Post-punk that influenced The House of Love's intensity
   * Key tracks: "She's Lost Control," "New Dawn Fades"

## A.R. Kane

### Influences:
1. **Miles Davis** - Jazz experimentation and fusion
2. **Cocteau Twins** - Ethereal soundscapes
3. **Dub Reggae** (particularly King Tubby) - Bass-heavy production and effects
4. **Free Jazz** - Improvisational approach
5. **Public Image Ltd.** - Post-punk experimentation

### Album Recommendations:
1. **Miles Davis** - "Bitches Brew" (1970)
   * Jazz fusion that influenced A.R. Kane's experimental approach
   * Key tracks: "Pharaoh's Dance," "Spanish Key"

2. **Cocteau Twins** - "Head Over Heels" (1983)
   * Ethereal dream pop that influenced A.R. Kane's soundscapes
   * Key tracks: "Sugar Hiccup," "In Our Angelhood"

3. **King Tubby** - "King Tubby Meets Rockers Uptown" (1976)
   * Dub reggae that influenced A.R. Kane's use of space and effects
   * Key tracks: "King Tubby Meets Rockers Uptown," "Keep on Dubbing"

4. **Ornette Coleman** - "The Shape of Jazz to Come" (1959)
   * Free jazz that influenced A.R. Kane's improvisational approach
   * Key tracks: "Lonely Woman," "Eventually"

5. **Public Image Ltd.** - "Metal Box" (1979)
   * Post-punk experimentation that influenced A.R. Kane's approach
   * Key tracks: "Albatross," "Poptones"
