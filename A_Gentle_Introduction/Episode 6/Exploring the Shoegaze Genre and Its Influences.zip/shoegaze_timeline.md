# Timeline of Key Albums in the Shoegaze Genre

This document presents a chronological timeline of significant albums in the development of the Shoegaze genre, from its precursors to its classic period and revival.

## Precursor Albums (1967-1988)

### 1967
- **The Velvet Underground** - "The Velvet Underground & Nico"
  * Pioneered the use of drone, feedback, and noise in rock music

### 1968
- **The Velvet Underground** - "White Light/White Heat"
  * Pushed the boundaries of noise and experimental rock

### 1970
- **The Beach Boys** - "Sunflower"
  * The track "All I Wanna Do" is retrospectively viewed as a shoegaze precursor

### 1981
- **The Cure** - "Faith"
  * Atmospheric post-punk with introspective lyrics and textured soundscapes

### 1982
- **The Cure** - "Pornography"
  * Dark, dense atmospheres and layered guitar effects

### 1983
- **Cocteau Twins** - "Head Over Heels"
  * Ethereal vocals and heavily processed guitars creating dreamlike soundscapes

### 1984
- **Cocteau Twins** - "Treasure"
  * Refined their ethereal sound with more complex arrangements

### 1985
- **The Jesus and Mary Chain** - "Psychocandy"
  * Landmark album combining pop melodies with walls of feedback and noise
  * Widely considered the most direct precursor to shoegaze

### 1986
- **Sonic Youth** - "EVOL"
  * Experimental guitar tunings and noise textures

### 1987
- **The Jesus and Mary Chain** - "Darklands"
  * More refined approach to their noise-pop formula
- **Dinosaur Jr.** - "You're Living All Over Me"
  * Combined melodic sensitivity with raw, distorted guitar work
- **Sonic Youth** - "Sister"
  * Further exploration of alternative tunings and noise
- **Spacemen 3** - "The Perfect Prescription"
  * Drone-heavy, psychedelic sound
- **Loop** - "Heaven's End"
  * Hypnotic, repetitive rhythms and heavily processed guitars

### 1988
- **Sonic Youth** - "Daydream Nation"
  * Influential noise rock album with expansive soundscapes
- **Dinosaur Jr.** - "Bug"
  * Raw emotion and guitar heroics within an indie rock framework
- **My Bloody Valentine** - "Isn't Anything"
  * Often considered the first true shoegaze album
- **The House of Love** - "The House of Love"
  * Bridged jangle pop and the more textural approach of shoegaze
- **A.R. Kane** - "69"
  * Experimental approach to guitar sounds and genre fusion
- **My Bloody Valentine** - "You Made Me Realise" EP
  * Breakthrough EP that established their shoegaze sound

## Classic Shoegaze Period (1989-1995)

### 1989
- **Spacemen 3** - "Playing with Fire"
  * Minimalist compositions with maximalist sound
- **Loop** - "Fade Out"
  * Refined their hypnotic sound
- **A.R. Kane** - "i"
  * Continued experimentation with dream pop and other genres

### 1990
- **Ride** - "Nowhere"
  * Crucial album for the introspective and textural vibe of shoegaze
- **Cocteau Twins** - "Heaven or Las Vegas"
  * Ethereal dream pop that influenced shoegaze aesthetics
- **Lush** - "Gala"
  * Accessible and melodic approach to shoegaze
- **Loop** - "A Gilded Eternity"
  * Final album from the influential precursor band
- **Pale Saints** - "The Comforts of Madness"
  * Dreamy textures with post-punk energy

### 1991
- **My Bloody Valentine** - "Loveless"
  * Masterpiece that stands as the genre's defining album
  * Kevin Shields' innovative guitar approach created a dense, immersive sonic experience
- **Swervedriver** - "Raise"
  * Demonstrated that shoegaze, grunge, and indie rock could coexist
- **Chapterhouse** - "Whirlpool"
  * Blended dance music influences with shoegaze textures
- **Slowdive** - "Just for a Day"
  * Dreamy, reverb-drenched debut

### 1992
- **Ride** - "Going Blank Again"
  * Evolution of shoegaze with more diverse and dynamic sonic territories
- **Catherine Wheel** - "Ferment"
  * Heavy and direct guitar riffs balanced with atmospheric vocals
- **The Boo Radleys** - "Everything's Alright Forever"
  * Noisy experimentation with pop sensibilities
- **Curve** - "Doppelgänger"
  * Electronic elements merged with shoegaze guitars and sultry vocals

### 1993
- **Slowdive** - "Souvlaki"
  * One of the most successful and well-known shoegaze albums alongside "Loveless"
  * Worked with Brian Eno to create lush, immersive soundscapes
- **Seefeel** - "Quique"
  * Merged traditional band formats with electronic production
- **The Boo Radleys** - "Giant Steps"
  * Expanded the shoegaze template with elements of psychedelia and jazz

### 1994
- **Lush** - "Split"
  * Exemplified the later stage of shoegaze with a more mature approach
- **Medicine** - "The Buried Life"
  * American shoegaze with extreme noise and experimental production
- **Flying Saucer Attack** - "Flying Saucer Attack"
  * Lo-fi, rural psychedelia meets shoegaze

### 1995
- **Slowdive** - "Pygmalion"
  * Shoegaze's swan song, experimental and avant-garde
  * Delved deep into minimalism and ambient atmospheres
- **Bowery Electric** - "Bowery Electric"
  * Combined shoegaze with trip-hop elements

## Decline Period (1996-2000)
During this period, shoegaze was sidelined by Britpop and grunge. Many shoegaze bands either disbanded or significantly changed their sound.

## Revival Period (2000s-Present)

### 2000
- **Sigur Rós** - "Ágætis byrjun"
  * Post-rock with shoegaze elements

### 2001
- **M83** - "M83"
  * Electronic music with shoegaze textures

### 2003
- **Alcest** - "Souvenirs d'un autre monde"
  * Pioneered blackgaze, combining black metal with shoegaze

### 2008
- **A Place to Bury Strangers** - "Exploding Head"
  * Neo-shoegaze with intense volume and noise

### 2013
- **My Bloody Valentine** - "m b v"
  * Long-awaited follow-up to "Loveless" after 22 years

### 2017
- **Slowdive** - "Slowdive"
  * Comeback album after 22 years

### 2018
- **Nothing** - "Dance on the Blacktop"
  * Modern shoegaze with heavier elements

### 2021
- **Parannoul** - "To See the Next Part of the Dream"
  * Bedroom shoegaze from South Korea, showing the global reach of the genre

### 2022
- **Deafheaven** - "Infinite Granite"
  * Blackgaze band moving toward a more pure shoegaze sound
