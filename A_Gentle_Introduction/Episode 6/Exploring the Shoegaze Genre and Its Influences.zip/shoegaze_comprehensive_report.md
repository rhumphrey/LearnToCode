# The Evolution of Shoegaze: From Precursors to Modern Revival

## Introduction

Shoegaze is a subgenre of indie and alternative rock that emerged in the United Kingdom in the late 1980s. The genre is characterized by its ethereal mixture of obscured vocals, guitar distortion and effects, feedback, and overwhelming volume. The name "shoegaze" (originally called "shoegazing") comes from the tendency of the genre's guitarists to stare down at their effects pedals during performances, seemingly gazing at their shoes.

This report explores the evolution of the shoegaze genre, from its precursors and influences to its classic period, decline, and eventual revival. It examines the key bands and albums that defined the genre, the musical influences that shaped it, and its lasting impact on alternative music.

## Origins and Precursors

### Early Influences

The roots of shoegaze can be traced back to several bands and musical movements that created rock soundscapes that could be felt rather than just heard. Each in their own way, these bands showed how rock music could be a form of escapism, a dreamy, introspective experience that enveloped listeners in waves of sound and emotion.

The Velvet Underground's experimental approach to rock in the late 1960s, particularly their use of drone, feedback, and noise as musical elements, laid important groundwork for shoegaze. Their 1967 debut album "The Velvet Underground & Nico" and 1968's "White Light/White Heat" pioneered techniques that would influence generations of experimental rock musicians.

Surprisingly, The Beach Boys also contributed to the shoegaze lineage. Their 1970 track "All I Wanna Do" from the album "Sunflower" has been retrospectively viewed as a precursor to shoegaze due to its dreamy atmosphere, reverb-drenched vocals, and immersive production.

### Post-Punk Foundations

Post-punk acts in the early 1980s, particularly Siouxsie and the Banshees and The Cure, were formative influences on shoegaze. The Cure's albums "Faith" (1981) and "Pornography" (1982) created atmospheric, melancholic soundscapes with layered guitars, reverb, and introspective lyrics that would influence shoegaze's emotional tone and sonic approach.

Cocteau Twins emerged as another crucial influence. Their dreamy, reverb-laden guitar work combined with Elizabeth Fraser's hauntingly beautiful vocals created soundscapes that transcended conventional rock structure. Albums like "Head Over Heels" (1983) and "Treasure" (1984) demonstrated how vocals could be used as another textural element rather than just a vehicle for lyrics.

### The Noise-Pop Revolution

The Jesus and Mary Chain's 1985 debut album "Psychocandy" is widely considered the most direct precursor to shoegaze. The album's unique combination of sweet pop melodies with harsh noise and feedback created a template that many shoegaze bands would follow. Their use of feedback and distortion as musical elements rather than just effects was revolutionary and directly influenced bands like My Bloody Valentine.

### Alternative Rock Experimentation

American underground bands also played a significant role in shaping shoegaze. Sonic Youth's experimental approach to guitar tunings and their creation of vast, noisy soundscapes provided a blueprint for shoegaze guitarists. Albums like "EVOL" (1986), "Sister" (1987), and "Daydream Nation" (1988) demonstrated how alternative tunings, feedback, and noise could be incorporated into song structures.

Dinosaur Jr. combined melodic sensitivity with raw, distorted guitar work. J Mascis's guitar solos and the band's approach to dynamics—alternating between quiet passages and explosive noise—influenced shoegaze bands' approach to composition and guitar playing. Albums like "You're Living All Over Me" (1987) and "Bug" (1988) showed how emotional vulnerability could coexist with noise and volume.

### Psychedelic Drones

Spacemen 3's drone-heavy, psychedelic sound embodied the trance-like, immersive quality that shoegaze would adopt. Albums like "The Perfect Prescription" (1987) and "Playing with Fire" (1989) demonstrated a minimalist approach to composition and a maximalist approach to sound that influenced bands like Slowdive and Ride.

Similarly, Loop's hypnotic, repetitive rhythms and heavily processed guitars created a psychedelic, immersive sound that influenced shoegaze's approach to rhythm and texture. Albums like "Heaven's End" (1987) and "A Gilded Eternity" (1990) showed how repetition and layered sound could create trance-like states.

### Genre-Blending Pioneers

A.R. Kane's experimental approach to guitar sounds and their fusion of dream pop, dub, free jazz, and psychedelia created a template for shoegaze's sonic experimentation. Their albums "69" (1988) and "i" (1989) have been credited with helping to coin the term "dream pop," which is closely associated with shoegaze.

The House of Love bridged the gap between jangle pop and the more textural approach of shoegaze. Their melodic sensibility combined with atmospheric guitar work influenced the more pop-oriented side of shoegaze, as demonstrated on their self-titled 1988 album.

## The Classic Shoegaze Era (1990-1995)

### The Scene That Celebrates Itself

By the late 1980s and early 1990s, a loose collection of bands in London began to develop what would become known as the shoegaze sound. This scene was sometimes called "The Scene That Celebrates Itself" due to the tendency of band members to attend each other's gigs and the perceived lack of competition between them.

### My Bloody Valentine and "Loveless"

My Bloody Valentine emerged as the definitive shoegaze band. After garnering some local popularity with their 1987 single "Sunny Sundae Smile," they started to move their sound more toward experimentation with noise and complex effects pedals. Their breakthrough came with the 1988 EP "You Made Me Realise" and album "Isn't Anything," which established many of the sonic elements that would define shoegaze.

However, it was their 1991 album "Loveless" that would become the genre's defining statement. After three years of recording that nearly bankrupted Creation Records, Kevin Shields created a masterpiece that pushed the boundaries of what was possible with guitars and studio production. Shields' innovative "glide guitar" technique (bending the guitar's tremolo arm while strumming) created a dense, immersive sonic experience unlike anything heard before.

"Loveless" perfected the balance between noise and melody, aggression and beauty, that characterizes shoegaze. The album's layered soundscapes, with vocals buried under waves of guitar, created the template that countless bands would follow. Its influence extends far beyond shoegaze, impacting alternative rock, dream pop, post-rock, and even electronic music.

### Ride and the More Accessible Side of Shoegaze

Ride's 1990 album "Nowhere" represented a more accessible approach to shoegaze. Guitarists Andy Bell and Mark Gardener created a swirling and immersive sound that enveloped the listener in a dreamlike atmosphere while maintaining more traditional song structures than some of their peers. Tracks like "Vapour Trail" showcased their signature shimmering guitars and vocal harmonies.

Their 1992 follow-up "Going Blank Again" ventured into more diverse and dynamic sonic territories, with the intense, layered guitars and ethereal vocals complemented with clearer song structures and a brighter, more upbeat tone. Its blend of dreamy textures with catchy melodies and dynamic songwriting marked a transition towards a more diverse and accessible sound for the band.

### Slowdive's Ethereal Approach

Slowdive represented the more ethereal, dreamy side of shoegaze. Their 1991 debut "Just for a Day" established their reverb-drenched sound, but it was their 1993 album "Souvlaki" that became one of the most successful and well-known shoegaze albums alongside "Loveless."

Working with music legends like Brian Eno and Ed Buller, Slowdive focused on their use of textures and space, creating a lush sound that enveloped the listener with emotional lyrics and immersive soundscapes. While "Loveless" represented the more aggressive, noise-oriented side of shoegaze, "Souvlaki" showcased the genre's more ethereal, dreamy aspects.

Their 1995 album "Pygmalion" pushed even further into experimental territory, delving deep into minimalism, ambient atmospheres, and electronic influences. It showcased the band's creative integrity and desire to push the boundaries of their sound and the genre itself, but was released as shoegaze was already in decline.

### Lush's Pop Sensibility

Lush brought a more melodic, pop-oriented approach to shoegaze. Their 1990 compilation "Gala" (combining earlier EPs) offered an accessible and melodic experience, with the vocal interplay between Emma Anderson and Miki Berenyi creating a signature sound that gave a feeling of both timelessness and impermanence.

Their 1992 album "Spooky," produced by Robin Guthrie of Cocteau Twins, showcased their evolution to a refined shoegaze approach. The album represented the more pop-oriented side of shoegaze, showing how the genre's sonic innovations could be applied to more traditional song structures.

By 1994's "Split," Lush exemplified the later stage of shoegaze, with a more mature and sophisticated approach to songwriting and production. The album was released during the changing landscape of early 90s British alternative music, with the shoegaze scene starting to give way to Britpop.

### Other Key Bands and Albums

Catherine Wheel's 1992 album "Ferment," with its heavy and direct guitar riffs, represented a more muscular approach to shoegaze that could appeal to fans of the rising grunge movement. Brian Futter's riffs played a crucial role, balanced with atmospheric vocals and a dynamic rhythmic section.

Swervedriver's 1991 album "Raise" demonstrated that shoegaze, grunge, and indie rock could coexist in a single album. Unlike many shoegaze bands, Swervedriver's music brought a more driving, aggressive edge to their sound, perfectly blending the introspective, texture-focused ethos of shoegaze with the energy and directness of American indie rock.

Seefeel's 1993 album "Quique" pushed the boundaries of what shoegaze could be by merging traditional band formats with electronic production. Their sonic signature leaned more towards electronic instrumentation and layers, with processed guitars and electronica textures creating a sound that gracefully merged ambient and rhythmic elements.

## Decline and Revival

### The Fall of Shoegaze

By the mid-1990s, shoegaze was in decline. The "anti-showmanship" and apparent self-indulgent attitude of the genre as a whole determined its acute fall. In the UK, the rise of Britpop marked a return to more traditional rock vibes, while on the other side of the Atlantic, the rise of grunge brought a raw, unpolished edge to mainstream rock: a stark contrast to the meditative aesthetics of shoegaze.

Both genres focused on the everyday struggle and depicted it through clear lyrics and musical structures, as opposed to the cryptic and intricate messages that defined shoegaze, which started being seen as an elitist and detached genre. In just a few years, all the most popular shoegaze bands disbanded or reinvented their style altogether.

### Post-Shoegaze Directions

Although short-lived, the influence of shoegaze did not fade away. It found new life in the post-rock genre, where many original shoegaze artists focused once their bands disbanded. Bands like Sigur Rós and Godspeed You! Black Emperor emphasized textures and atmospheres in the early 2000s.

### The Revival

A renewed interest in shoegaze began in the late 2000s and early 2010s, with the emergence of new genres such as nu-gaze. Bands like M83, Deerhunter, and Beach House modernized the shoegaze sound, often blending it with elements of electronic, dream pop, and indie rock.

This renewed interest led to the reunion of many iconic shoegaze bands, including My Bloody Valentine and Slowdive. My Bloody Valentine released "m b v" in 2013, their first album in 22 years, while Slowdive released their self-titled comeback album in 2017 after a 22-year hiatus.

The genre also spawned new subgenres like blackgaze, pioneered by bands like Alcest, which combines black metal with shoegaze textures. This demonstrates the continued relevance and adaptability of the shoegaze sound in the 21st century.

## Legacy and Influence

In just five years, shoegaze revolutionized the way many of us experience and perceive music, thanks to an innovative and introspective approach that is now the hallmark of the most ambitious and genre-bending rock bands.

Diverse and yet incredibly cohesive, shoegaze's ecosystem offers an immersive experience for the curious listener who wants to explore the most contemplative side of rock. Its influence can be heard in countless contemporary bands across various genres, from indie rock to metal to electronic music.

The genre's emphasis on texture, atmosphere, and emotion over traditional rock showmanship has proven to be a lasting contribution to alternative music. Its approach to using studio technology and effects as compositional tools rather than just enhancements has influenced production techniques across many genres.

Perhaps most importantly, shoegaze demonstrated that rock music could be introspective and atmospheric while still maintaining emotional power. This balance between experimentation and accessibility continues to inspire musicians seeking to push the boundaries of what rock music can be.

## Conclusion

Shoegaze may have had a brief moment as a defined genre, but its influence has far outlasted its original lifespan. From its roots in post-punk, noise pop, and psychedelia to its revival and continued influence in the 21st century, shoegaze represents a unique approach to rock music that prioritizes texture, atmosphere, and emotional depth.

The genre's key innovations—the use of effects as compositional elements, the treatment of vocals as another textural layer, the balance between noise and melody, and the creation of immersive sonic environments—continue to resonate with musicians and listeners alike. As new generations discover albums like "Loveless," "Souvlaki," and "Nowhere," shoegaze's legacy is assured for years to come.

In an era of music increasingly defined by digital production and algorithmic playlists, shoegaze's handcrafted, immersive soundscapes offer a reminder of the emotional power of sound itself. The genre may have been named for musicians who seemed disconnected from their audience, but its music creates a profound connection through shared sonic experience—a testament to the enduring power of shoegaze's dreamy, noisy, beautiful vision.
