# Mixture of Experts (MoE) - Notes from NVIDIA Developer Blog

## Overview
- Mixture of experts (MoE) architectures have recently emerged in large language models (LLMs)
- Used in both proprietary LLMs (like GPT-4) and community models (like Mistral Mixtral 8x7B)
- Strong performance of Mixtral model has raised interest in MoE for LLM architectures

## Definition
- MoE is an architectural pattern for neural networks that splits computation of a layer or operation into multiple "expert" subnetworks
- These subnetworks independently perform their own computation, results are combined for final output
- Can be either dense (every expert used for every input) or sparse (subset of experts used for each input)

## Applications in LLM Architectures

### Model Capacity Benefits
- Model capacity: level of complexity a model can understand or express
- Models with larger numbers of parameters generally have greater capacity
- MoE effectively increases capacity by replacing layers with MoE layers where expert subnetworks are same size as original layer
- Research shows fully dense models generally outperform MoE models of similar size trained on same amount of tokens
- However, sparse MoEs are more flop-efficient per parameter used

### Cost Reduction
- MoE models reduce cost by being more flop-efficient per weight
- Under fixed time/compute constraints, more tokens can be processed
- Models with more parameters need more samples to converge
- Can train better MoE models than dense models on fixed budget
- Example: Llama 2 training reportedly spent 3.3 million NVIDIA A100 GPU hours in pretraining
- That's equivalent to 134 days on 1,024 GPUs at full capacity with no downtime

### Latency Benefits
- MoE architecture delivers decreased first-token serving latency with large prompts and batches
- Especially important for use cases like retrieval-augmented generation (RAG) and autonomous agents
- These applications may require many calls to the model, compounding single-call latency

## Technical Implementation

### Key Components
1. "Expert" subnetworks that compose the mixture (used for both dense and sparse MoE)
2. Routing algorithm (for sparse models) to determine which experts process which tokens
3. Optional weighting mechanism for weighted average of expert outputs

### Application in Transformer Architecture
- Typically applied to Multi-Layer Perceptrons (MLPs) within transformer blocks
- MLP replaced with set of expert MLP subnetworks
- Results combined to produce MLP MoE output using averaging or summation
- Can also be applied to other parts of transformer architecture:
  - Projection layers that transform inputs into Q, K, V matrices (SwitchHead paper)
  - Attention heads themselves

### Routing Algorithms
- Determine which experts are activated for particular input
- Range from simple (uniform selection or binning across average values of tensors) to complex
- Key factors: model accuracy and load balancing
- Trade-off between accuracy and flop efficiency
- Perfectly load-balanced routing might reduce accuracy per token
- Most accurate routing might unevenly distribute tokens between experts
- Many algorithms designed to maximize accuracy while minimizing bottlenecks
- Mixtral 8x7B uses Top-K algorithm to route tokens

## Example: Mixtral 8x7B
- Has 32 sequential transformer blocks
- Each MLP layer replaced with sparse MoE block with eight experts
- Only two experts activated for each token
- Remaining layers (self-attention, normalization) shared by all tokens
