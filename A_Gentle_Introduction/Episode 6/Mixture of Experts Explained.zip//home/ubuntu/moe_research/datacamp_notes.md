# Mixture of Experts (MoE) - Notes from DataCamp Article

## Definition
- Mixture of Experts (MoE) is a machine learning technique where multiple specialized models (experts) work together, with a gating network selecting the best expert for each input.
- Originated from the 1991 paper "Adaptive Mixture of Local Experts"
- Has been employed in multi-trillion parameter models, such as the 1.6 trillion parameter open-sourced Switch Transformers

## Core Concept
- MoE operates like a team of specialists, each with unique expertise
- Divides complex tasks among smaller, specialized networks called "experts"
- Each expert focuses on a specific aspect of the problem
- Similar to having different specialists for different tasks (doctor, mechanic, chef)

## Key Components

### Expert Networks
- Individual neural networks trained on different datasets or tasks
- Designed to be sparse (only a few are active at any given time)
- Each focuses on a particular type of task or data
- Prevents the system from being overwhelmed

### Gating Network (Router)
- Neural network that analyzes input data
- Determines which experts are best suited to handle the input
- Assigns "weight" or importance score to each expert
- Selects experts with highest weights to process the data

### Routing Algorithms
1. **Top-k routing**: Picks the top 'k' experts with highest affinity scores
2. **Expert choice routing**: Experts decide which data they can handle best (for load balancing)
3. **Sparse routing**: Only activates a few experts for each piece of data (uses less computational power)

## How MoE Works

### Training Phase
1. **Expert Training**: Each component trains on specific subset of data/tasks
   - Focuses on a particular aspect of the broader problem
   - Provided with data relevant to its assigned task
   - Follows standard neural network training process
   - Learns to minimize the loss function for its specific data subset

2. **Gating Network Training**: Learns to select most suitable expert for given input
   - Trained alongside expert networks
   - Receives same input as experts
   - Learns to predict probability distribution over experts
   - Trained using optimization methods that include both accuracy of gating network and performance of selected experts

3. **Joint Training**: Entire MoE system (experts + gating network) trained together
   - Ensures both components are optimized to work in harmony
   - Loss function combines losses from individual experts and gating network
   - Encourages collaborative optimization approach
   - Combined loss gradients propagated through both networks

### Inference Phase
1. **Input Routing**: Gating network assesses input and creates probability distribution
   - Pivotal in deciding which models should process specific input
   - Directs input to most suitable models based on patterns learned during training
   - Optimizes decision-making process

2. **Expert Selection**: Only select few models chosen to process each input
   - Selection determined by probabilities assigned by gating network
   - Usually one or a few experts are chosen
   - Helps efficient use of computational resources
   - Leverages specialized knowledge within MoE framework

3. **Output Combination**: Final output combines results from selected experts
   - Combines outputs based on weights assigned by gating network
   - Designed to keep inference costs minimal

## Benefits of MoE
1. **Performance**: Selectively activating only relevant experts leads to improved speed and reduced resource consumption
2. **Flexibility**: Diverse capabilities of experts make MoE models highly adaptable to a wide range of tasks
3. **Fault tolerance**: "Divide and conquer" approach enhances resilience to failures - if one expert fails, it doesn't affect the entire model
4. **Scalability**: Decomposing complex problems into smaller, manageable tasks helps handle increasingly complicated inputs
5. **Efficiency**: Only experts who are good at a particular part of the problem are used, saving computing power
6. **Better results**: Each expert focuses on what they're good at, making the overall solution more accurate

## Applications of MoE

### Natural Language Processing (NLP)
- Offers improved efficiency, faster pre-training, and competitive inference speeds
- In traditional dense models, all parameters are used for all inputs; MoE allows running only specific parts based on input
- Example: Microsoft's Z-code translation API supports massive scale of model parameters while keeping compute constant

### Computer Vision
- Google's V-MoEs (Vision Transformers) showcase effectiveness in computer vision tasks
- Partitions images into smaller patches and feeds them to gating/routing layer
- Dynamically selects appropriate experts for each patch, optimizing accuracy and efficiency
- Offers flexibility to decrease number of selected experts per token to save time and compute

### Recommendation Systems
- Google researchers proposed MMoE (Multi-Gate Mixture of Experts) for YouTube video recommendations
- Groups task objectives into categories (engagement and satisfaction)
- Uses candidate videos, user, and context features to predict probabilities for user behavior categories
- Note: MoE layer not applied directly to input due to high dimensionality causing significant training and serving costs

## Challenges of MoE

### Memory Requirements
- Sparse models require substantial memory during execution
- All experts need to be stored in memory
- Can be a significant limitation in systems with low VRAM

### Training Complexity
- Training MoE models is more complex than training a single model
- Requires careful balancing of expert utilization
- Need to manage routing decisions and expert specialization

### Industry Adoption
- Despite challenges, MoEs have seen wide-scale adoption
- Learning procedure divides tasks into appropriate subtasks
- Each subtask can be solved by a simple expert network
- Capability translates to parallelizable training and fast inference
- Makes MoEs lucrative for large-scale systems
