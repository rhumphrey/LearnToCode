# Mixture of Experts (MoE) - Notes from Hugging Face Blog

## Key Points from TL;DR

- MoEs are **pretrained much faster** vs. dense models
- Have **faster inference** compared to a model with the same number of parameters
- Require **high VRAM** as all experts are loaded in memory
- Face many **challenges in fine-tuning**, but recent work with MoE instruction-tuning is promising

## What is a Mixture of Experts (MoE)?

- The scale of a model is one of the most important axes for better model quality
- Given a fixed computing budget, training a larger model for fewer steps is better than training a smaller model for more steps
- MoE enables models to be pretrained with far less compute
- This allows dramatically scaling up the model or dataset size with the same compute budget as a dense model
- A MoE model achieves the same quality as its dense counterpart much faster during pretraining

## MoE Architecture in Transformers

In the context of transformer models, a MoE consists of two main elements:

1. **Sparse MoE layers** instead of dense feed-forward network (FFN) layers
   - Each layer has a certain number of "experts" (e.g., 8)
   - Each expert is a neural network (typically FFNs)
   - Can also be more complex networks or even a MoE itself (hierarchical MoEs)

2. **Gate network or router**
   - Determines which tokens are sent to which expert
   - Example: token "More" sent to second expert, token "Parameters" sent to first network
   - Can send a token to more than one expert
   - Router has learned parameters and is pretrained with the rest of the network

## Benefits and Challenges

### Benefits
- **Efficient pretraining**: MoEs enable significantly more compute-efficient pretraining
- **Faster inference**: Only some parameters are used during inference, leading to much faster inference compared to a dense model with the same number of parameters

### Challenges
- **Memory requirements**: All parameters need to be loaded in RAM, so memory requirements are high
  - Example: Mixtral 8x7B needs enough VRAM to hold a dense 47B parameter model
  - Only FFN layers are treated as individual experts; rest of model parameters are shared
- **Fine-tuning difficulties**: Historically struggled to generalize during fine-tuning, leading to overfitting

## Historical Development

- Roots from 1991 paper "Adaptive Mixture of Local Experts"
- Similar to ensemble methods - separate networks each handling different subset of training cases
- Each expert specializes in different region of input space
- Gating network determines weights for each expert
- Between 2010-2015, two research areas contributed:
  1. **Experts as components**: MoEs as layers in multilayer networks
  2. **Conditional Computation**: Dynamically activate/deactivate components based on input token
- 2017: Shazeer et al. (including Geoffrey Hinton and Jeff Dean) scaled to 137B LSTM by introducing sparsity
- MoEs have allowed training multi-trillion parameter models (e.g., 1.6T parameters Switch Transformers)
- Applied in both NLP and Computer Vision domains

## Sparsity in MoE

- Uses conditional computation - only parts of network active on per-example basis
- Allows scaling model size without increasing computation
- Challenges include uneven batch sizes and underutilization
  - Example: If 10 tokens in batch, 5 might go to one expert, other 5 to different experts
- Gating network (G) decides which experts (E) to use for input
- Traditional setup: simple network with softmax function that learns which expert to use
