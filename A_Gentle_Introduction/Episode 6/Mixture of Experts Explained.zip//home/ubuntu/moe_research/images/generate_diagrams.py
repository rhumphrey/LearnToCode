import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle, FancyArrowPatch

# Create figure and axis
fig, ax = plt.subplots(figsize=(10, 8))

# Define colors
expert_color = '#AED6F1'
router_color = '#F5CBA7'
input_output_color = '#D5F5E3'
arrow_color = '#566573'

# Create boxes for components
input_box = Rectangle((4, 7), 2, 1, facecolor=input_output_color, edgecolor='black', alpha=0.8)
router_box = Rectangle((4, 5), 2, 1, facecolor=router_color, edgecolor='black', alpha=0.8)
expert1_box = Rectangle((1, 3), 2, 1, facecolor=expert_color, edgecolor='black', alpha=0.8)
expert2_box = Rectangle((4, 3), 2, 1, facecolor=expert_color, edgecolor='black', alpha=0.8)
expert3_box = Rectangle((7, 3), 2, 1, facecolor=expert_color, edgecolor='black', alpha=0.8)
combine_box = Rectangle((4, 1), 2, 1, facecolor=router_color, edgecolor='black', alpha=0.8)
output_box = Rectangle((4, -1), 2, 1, facecolor=input_output_color, edgecolor='black', alpha=0.8)

# Add boxes to plot
for box in [input_box, router_box, expert1_box, expert2_box, expert3_box, combine_box, output_box]:
    ax.add_patch(box)

# Add arrows
arrow1 = FancyArrowPatch((5, 7), (5, 6), arrowstyle='->', color=arrow_color, linewidth=1.5)
arrow2a = FancyArrowPatch((4.5, 5), (2, 4), arrowstyle='->', color=arrow_color, linewidth=1.5)
arrow2b = FancyArrowPatch((5, 5), (5, 4), arrowstyle='->', color=arrow_color, linewidth=1.5)
arrow2c = FancyArrowPatch((5.5, 5), (8, 4), arrowstyle='->', color=arrow_color, linewidth=1.5)
arrow3a = FancyArrowPatch((2, 3), (4.5, 2), arrowstyle='->', color=arrow_color, linewidth=1.5)
arrow3b = FancyArrowPatch((5, 3), (5, 2), arrowstyle='->', color=arrow_color, linewidth=1.5)
arrow3c = FancyArrowPatch((8, 3), (5.5, 2), arrowstyle='->', color=arrow_color, linewidth=1.5)
arrow4 = FancyArrowPatch((5, 1), (5, 0), arrowstyle='->', color=arrow_color, linewidth=1.5)

# Add arrows to plot
for arrow in [arrow1, arrow2a, arrow2b, arrow2c, arrow3a, arrow3b, arrow3c, arrow4]:
    ax.add_patch(arrow)

# Add text labels
ax.text(5, 7.5, 'Input (x)', ha='center', va='center', fontsize=12)
ax.text(5, 5.5, 'Gating Network\n(Router)', ha='center', va='center', fontsize=12)
ax.text(2, 3.5, 'Expert 1\nf₁(x)', ha='center', va='center', fontsize=12)
ax.text(5, 3.5, 'Expert 2\nf₂(x)', ha='center', va='center', fontsize=12)
ax.text(8, 3.5, 'Expert n\nfₙ(x)', ha='center', va='center', fontsize=12)
ax.text(5, 1.5, 'Weighted Sum\nΣᵢ w(x)ᵢfᵢ(x)', ha='center', va='center', fontsize=12)
ax.text(5, -0.5, 'Output', ha='center', va='center', fontsize=12)

# Add weights labels
ax.text(3.5, 5.3, 'w(x)₁', ha='center', va='center', fontsize=10)
ax.text(5, 4.7, 'w(x)₂', ha='center', va='center', fontsize=10)
ax.text(6.5, 5.3, 'w(x)ₙ', ha='center', va='center', fontsize=10)

# Set axis limits and remove ticks
ax.set_xlim(0, 10)
ax.set_ylim(-1.5, 8.5)
ax.set_xticks([])
ax.set_yticks([])
ax.axis('off')

# Add title
ax.set_title('Mixture of Experts (MoE) Architecture', fontsize=14, pad=20)

# Save the figure
plt.tight_layout()
plt.savefig('/home/ubuntu/moe_research/images/moe_architecture.png', dpi=300, bbox_inches='tight')
plt.close()

# Create a second diagram for sparse vs dense MoE
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

# Dense MoE (left)
ax1.set_title('Dense MoE', fontsize=14)
ax1.add_patch(Rectangle((2, 6), 6, 1, facecolor=input_output_color, edgecolor='black', alpha=0.8))
ax1.text(5, 6.5, 'Input', ha='center', va='center', fontsize=12)

# Add router
ax1.add_patch(Rectangle((2, 4), 6, 1, facecolor=router_color, edgecolor='black', alpha=0.8))
ax1.text(5, 4.5, 'Router', ha='center', va='center', fontsize=12)

# Add experts
for i in range(5):
    x = 1 + i*2
    ax1.add_patch(Rectangle((x, 2), 1.5, 1, facecolor=expert_color, edgecolor='black', alpha=0.8))
    ax1.text(x+0.75, 2.5, f'E{i+1}', ha='center', va='center', fontsize=10)
    # Add arrows from router to all experts
    ax1.add_patch(FancyArrowPatch((5, 4), (x+0.75, 3), arrowstyle='->', color=arrow_color, linewidth=1))
    # Add arrows from all experts to output
    ax1.add_patch(FancyArrowPatch((x+0.75, 2), (5, 1), arrowstyle='->', color=arrow_color, linewidth=1))

# Add output
ax1.add_patch(Rectangle((2, 0), 6, 1, facecolor=input_output_color, edgecolor='black', alpha=0.8))
ax1.text(5, 0.5, 'Output', ha='center', va='center', fontsize=12)

# Sparse MoE (right)
ax2.set_title('Sparse MoE (Top-2)', fontsize=14)
ax2.add_patch(Rectangle((2, 6), 6, 1, facecolor=input_output_color, edgecolor='black', alpha=0.8))
ax2.text(5, 6.5, 'Input', ha='center', va='center', fontsize=12)

# Add router
ax2.add_patch(Rectangle((2, 4), 6, 1, facecolor=router_color, edgecolor='black', alpha=0.8))
ax2.text(5, 4.5, 'Router', ha='center', va='center', fontsize=12)

# Add experts
for i in range(5):
    x = 1 + i*2
    ax2.add_patch(Rectangle((x, 2), 1.5, 1, facecolor=expert_color, edgecolor='black', alpha=0.8))
    ax2.text(x+0.75, 2.5, f'E{i+1}', ha='center', va='center', fontsize=10)
    
    # Only add arrows to/from experts 2 and 4 (simulating sparse routing)
    if i in [1, 3]:
        # Add arrows from router to selected experts
        ax2.add_patch(FancyArrowPatch((5, 4), (x+0.75, 3), arrowstyle='->', color=arrow_color, linewidth=1.5))
        # Add arrows from selected experts to output
        ax2.add_patch(FancyArrowPatch((x+0.75, 2), (5, 1), arrowstyle='->', color=arrow_color, linewidth=1.5))
    else:
        # Add faded experts
        ax2.add_patch(Rectangle((x, 2), 1.5, 1, facecolor=expert_color, edgecolor='black', alpha=0.3))
        ax2.text(x+0.75, 2.5, f'E{i+1}', ha='center', va='center', fontsize=10, alpha=0.3)

# Add output
ax2.add_patch(Rectangle((2, 0), 6, 1, facecolor=input_output_color, edgecolor='black', alpha=0.8))
ax2.text(5, 0.5, 'Output', ha='center', va='center', fontsize=12)

# Set axis limits and remove ticks
for ax in [ax1, ax2]:
    ax.set_xlim(0, 10)
    ax.set_ylim(-0.5, 7.5)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.axis('off')

# Add title
fig.suptitle('Dense vs. Sparse Mixture of Experts', fontsize=16, y=0.98)

# Save the figure
plt.tight_layout()
plt.savefig('/home/ubuntu/moe_research/images/moe_dense_vs_sparse.png', dpi=300, bbox_inches='tight')
plt.close()
