# Mixture of Experts (MoE) - Notes from Wikipedia

## Definition and Basic Theory
- Mixture of experts (MoE) is a machine learning technique where multiple expert networks (learners) are used to divide a problem space into homogeneous regions
- Represents a form of ensemble learning
- Also called "committee machines"

## Components
MoE always has the following components, implemented differently according to the problem:
- **Experts** (f₁, ..., fₙ): Each taking the same input x and producing outputs f₁(x), ..., fₙ(x)
- **Weighting function** (also known as gating function): Takes input x and produces a vector of outputs w(x)₁, ..., w(x)ₙ
- **Parameters**: θ = (θ₀, θ₁, ..., θₙ) where θ₀ is for the weighting function and θ₁, ..., θₙ are for the experts
- **Output**: Produces a single output by combining experts according to weights, usually by f(x) = Σᵢ w(x)ᵢfᵢ(x)

## Training
- Both experts and weighting function are trained by minimizing some loss function, generally via gradient descent
- Much freedom in choosing precise form of experts, weighting function, and loss function

## Historical Variants

### Meta-pi Network
- Uses w(x)ᵢfᵢ(x) as the output
- Trained by performing gradient descent on mean-squared error loss
- Original application: classifying phonemes in speech signal from different Japanese speakers
- Found that experts specialized for different speakers

### Adaptive Mixtures of Local Experts
- Uses a gaussian mixture model
- Each expert predicts a gaussian distribution
- Weighting function is a linear-softmax function
- Trained by maximal likelihood estimation
- Experts become specialized through positive feedback effect
- Each expert moves apart from the rest to take care of a local region alone

### Hierarchical MoE
- Uses multiple levels of gating in a tree structure
- Each gating is a probability distribution over the next level of gatings
- Experts are on the leaf nodes of the tree
- Similar to decision trees

### Other Variants
- Can be trained by expectation-maximization algorithm
- Gating functions: softmax, gaussian distributions, exponential families
- Hard MoE: only highest ranked expert is chosen (accelerates training and inference)
- Experts can use various distributions: gaussian, Laplace, Student's t-distribution
- For classification: logistic regression experts, multinomial logistic regression
- Mixture of softmaxes for autoregressive language modeling

## Deep Learning Applications
- MoE found applications in running the largest models as a way to perform conditional computation
- Only parts of the model are used, chosen according to input
- Earliest application to deep learning: 2013
- Proposed using different gating network at each layer in deep neural network
