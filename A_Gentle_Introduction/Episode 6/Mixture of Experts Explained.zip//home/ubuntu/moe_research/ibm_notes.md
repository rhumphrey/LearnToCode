# Mixture of Experts (MoE) - Notes from IBM Article

## Definition and Core Concept
- Mixture of experts (MoE) is a machine learning approach that divides an artificial intelligence (AI) model into separate sub-networks (or "experts"), each specializing in a subset of the input data, to jointly perform a task
- Enables large-scale models, even those comprising many billions of parameters, to greatly reduce computation costs during pre-training and achieve faster performance during inference time
- Achieves efficiency through selectively activating only the specific experts needed for a given task, rather than activating the entire neural network for every task

## Historical Development
- Core premise originates from the 1991 paper "Adaptive Mixture of Local Experts"
- Paper proposed training an AI system composed of separate networks that each specialized in different subset of training cases
- Required training both the "expert networks" and a gating network that determines which expert should be used for each subtask
- Experimental model was significantly faster to train: reached target accuracy threshold in half as many training epochs as conventional model

## Modern Applications
- As deep learning models for generative AI have grown increasingly large and computationally demanding, MoE offers a means to address the tradeoff between capacity of larger models and efficiency of smaller models
- Notable applications in natural language processing (NLP)
- Leading large language models (LLMs) like Mistral's Mixtral 8x7B and (reportedly) OpenAI's GPT-4 have employed MoE architecture

## Technical Implementation
- Modern deep learning models are built from artificial neural networks with multiple layers of interconnected nodes
- Connections between different layers and neurons are mediated by learnable model parameters
- Larger number of parameters increases model capacity but also increases computational resources needed
- Unlike conventional dense models, MoE uses conditional computation to enforce sparsity
- Rather than using entire network for every input, MoE models learn a mapping function to determine which portions of the network are most effective for a given input

## How MoE Models Work
- Process data by designating a number of "experts" (sub-networks within larger neural network)
- Train a gating network (router) to activate only specific expert(s) best suited to given input
- Replace traditional dense feed-forward network (FFN) layers with sparse MoE layers (blocks)
- Expert blocks can be single layers, self-contained FFNs, or even nested MoEs

## Example: Mixtral 8x7B
- Each layer composed of 8 feedforward blocks (experts), each with 7 billion parameters
- For every token, at each layer, router network selects two of eight experts to process data
- Combines outputs of those two experts and passes result to following layer
- Specific experts selected may differ between layers
- Some blocks (self-attention mechanism) are shared across all 8 experts
- Total of about 47 billion parameters (not 56 billion, due to parameter sharing)
- Despite having fewer parameters than Llama 2 (70B), Mixtral outperforms it with much greater speed

## Parameter Counts in MoE
- Sparse parameter count: total number of parameters (measure of model capacity)
- Active parameter count: parameters actually used to process individual token (measure of computational costs)
- Mixtral has 46.7 billion parameters but only uses 12.9 billion active parameters per token
- Despite efficiency in computation, entire model's parameters must be loaded into memory (RAM/VRAM requirements remain high)
